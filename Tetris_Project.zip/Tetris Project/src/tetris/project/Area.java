package tetris.project;

import TetrisBlocks.*;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

public class Area extends JPanel{
    
    private int rows;
    private int columns;
    private int cells;
    private Color[][] back;
    private Block bblock;
    
    private Block[] blocks;
    
    // Mmebuat area yang akan digunakan pada game
    public Area(JPanel placeholder, int col){
        placeholder.setVisible(false);
        this.setBounds(placeholder.getBounds());
        this.setBackground(placeholder.getBackground());
        this.setBorder(placeholder.getBorder());
        
        columns = col;
        cells = this.getBounds().width / columns;
        rows = this.getBounds().height / cells;
        blocks = new Block[]{new IShape(), new JShape(), new LShape(), new OShape(), new SShape(), new TShape(), new ZShape()};
    }
    
    public void backArray(){
       back = new Color[rows][columns]; 
    }
    
    // Digunakan untuk spawn block pada area game
    public void spawn(){
        Random rand = new Random();
        bblock = blocks[rand.nextInt(blocks.length)];
        bblock.spawn(columns);
    }
    
    public boolean outofbounds(){
        if(bblock.getY() < 0){
            bblock = null;
            return true;
        }
        return false;
    }
    
    // Membuat block bergerak jatuh ke bawah
    public boolean fall(){
        if(check() == false){
            return false;
        }
       bblock.down();
       repaint();
       return true;
    }
    
    public void Right(){
        if(bblock == null) return;
        if(checkRight() == false){
            return;
        }
        bblock.right();
        repaint();
    }
    
    public void Left(){
        if(bblock == null) return;
        if(checkLeft() == false){
            return;
        }
        bblock.left();
        repaint();
    }
    
    public void Down(){
        if(bblock == null) return;
        while(check()){
            bblock.down();
        }
        repaint();
    }
    
    public void Rotate(){
        if(bblock == null) return;
        bblock.rotate();
        if(bblock.getLeft() < 0){
            bblock.setX(0);
        }
        if(bblock.getRight() >= columns){
            bblock.setX(columns - bblock.getWidth());
        }
        if(bblock.getBottom() >= rows){
            bblock.setX(rows - bblock.getHeight());
        }
        repaint();
    }
    
    // Mengecek jika block sudah sampai dasar atau belum
    private boolean check(){
        if(bblock.getBottom() == rows){
            return false;
        }
        int[][] shape = bblock.getShape();
        int width = bblock.getWidth();
        int height = bblock.getHeight();
        
        for(int col = 0; col < width; col++){
            for(int row = height - 1; row >= 0; row--){
                if(shape[row][col] != 0){
                    int x = col + bblock.getX();
                    int y = row + bblock.getY() + 1;
                    if(y < 0){
                        break;
                    }
                    if(back[y][x] != null){
                        return false;
                    }
                    break;
                }
            }
        }
        return true;
    }
    
    private boolean checkLeft(){
        if(bblock.getLeft() == 0){
            return false;
        }
        int[][] shape = bblock.getShape();
        int width = bblock.getWidth();
        int height = bblock.getHeight();
        
        for(int row = 0; row < height; row++){
            for(int col = 0; col < width; col++){
                if(shape[row][col] != 0){
                    int x = col + bblock.getX() - 1;
                    int y = row + bblock.getY();
                    if(y < 0){
                        break;
                    }
                    if(back[y][x] != null){
                        return false;
                    }
                    break;
                }
            }
        }
        return true;
    }
    private boolean checkRight(){
        if(bblock.getRight() == columns){
            return false;
        }
        int[][] shape = bblock.getShape();
        int width = bblock.getWidth();
        int height = bblock.getHeight();
        
        for(int row = 0; row < height; row++){
            for(int col = width - 1; col >= 0; col--){
                if(shape[row][col] != 0){
                    int x = col + bblock.getX() + 1;
                    int y = row + bblock.getY();
                    if(y < 0){
                        break;
                    }
                    if(back[y][x] != null){
                        return false;
                    }
                    break;
                }
            }
        }
        return true;
    }
    
    public int clear(){
        boolean fill;
        int lines = 0;
        for(int row = rows - 1; row >= 0; row--){
            fill = true;
            for(int col = 0; col < columns; col++){
                if(back[row][col] == null){
                    fill = false;
                    break;
                }
            }
            if(fill){
                lines++;
                clears(row);
                shift(row);
                clears(0);
                
                row++;
                repaint();
            }
        }
        return lines;
    }
    
    public void clears(int row){
        for(int i = 0; i < columns; i++){
                    back[row][i] = null;
                }
    }
    public void shift(int row){
        for(int r = row; r > 0; r--){
            for(int c = 0; c < columns; c++){
                back[r][c] = back[r - 1][c];
            }
        }
    }
    
    // Memindahkan block ke area background
    public void BlockToBack(){
        int[][] shape = bblock.getShape();
        int height = bblock.getHeight();
        int width = bblock.getWidth();
        
        int x = bblock.getX();
        int y = bblock.getY();
        
        Color color = bblock.getColor();
        for(int t = 0; t < height; t++){
            for (int f = 0; f < width; f++){
                if(shape[t][f] == 1){
                    back[t + y][f + x] = color;
                }
            }
        }
    }
            
    // Membuat block pada area game
    private void draw(Graphics h){
        int height = bblock.getHeight();
        int width = bblock.getWidth();
        Color a = bblock.getColor();
        int[][] shape = bblock.getShape();
        
        for(int row = 0; row < height; row++){
            for(int col = 0; col < width; col++){
                if(shape[row][col] == 1){
                    int x = (bblock.getX() + col) * cells;
                    int y = (bblock.getY() + row) * cells;
                    grid(h, a, x, y);
                }
            }
        }
    }
    
    //Membuat shape di background pada area
    private void drawBack(Graphics h){
        Color color;
        for(int row = 0; row < rows; row++){
            for(int col = 0; col < columns; col++){
                color = back[row][col];
                if(color != null){
                    int x = col * cells;
                    int y = row * cells;
                    
                    grid(h, color, x, y);
                }
            }
        }
    }
    
    private void grid(Graphics h, Color color, int x, int y){
        h.setColor(color);
        h.fillRect(x, y , cells, cells);
        h.setColor(Color.black);
        h.drawRect(x, y , cells, cells);
    }
    
    @Override
    protected void paintComponent(Graphics h){
        super.paintComponent(h);
        drawBack(h);
        draw(h);
    }
}
