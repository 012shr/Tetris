package tetris.project;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.KeyStroke;

public class Game extends javax.swing.JFrame {

    private Area a;
    private GameThread gt;
    
    public Game() {
        initComponents();
        a = new Area(PlaceHolder, 10);
        // Membuat grid sebesar lebar / 10 dan tinggi / (lebar / 10)
        this.add (a);
        
        Controls();
        
    }

    private void Controls(){
        InputMap im = this.getRootPane().getInputMap();
        ActionMap am = this.getRootPane().getActionMap();
        im.put(KeyStroke.getKeyStroke("RIGHT"), "right");
        im.put(KeyStroke.getKeyStroke("LEFT"), "left");
        im.put(KeyStroke.getKeyStroke("UP"), "up");
        im.put(KeyStroke.getKeyStroke("DOWN"), "down");
        
        am.put("right", new AbstractAction(){
        @Override
        public void actionPerformed(ActionEvent e){
            a.Right();
        }
    });
        am.put("left", new AbstractAction(){
        @Override
        public void actionPerformed(ActionEvent e){
            a.Left();
        }
    });
        am.put("up", new AbstractAction(){
        @Override
        public void actionPerformed(ActionEvent e){
            a.Rotate();
        }
    });
        am.put("down", new AbstractAction(){
        @Override
        public void actionPerformed(ActionEvent e){
            a.Down();
        }
    });
        
    }
    
    public void StartGame(){
        a.backArray();
        gt = new GameThread(a, this);
        gt.start();
    }

    public void scoreupdate(int score){
        Score.setText("Score "+ score);
        
    }
    
    public void levelupdate(int level){
        Level.setText("Level "+ level);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PlaceHolder = new javax.swing.JPanel();
        Score = new javax.swing.JLabel();
        Level = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        PlaceHolder.setBackground(new java.awt.Color(153, 153, 153));
        PlaceHolder.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        javax.swing.GroupLayout PlaceHolderLayout = new javax.swing.GroupLayout(PlaceHolder);
        PlaceHolder.setLayout(PlaceHolderLayout);
        PlaceHolderLayout.setHorizontalGroup(
            PlaceHolderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 198, Short.MAX_VALUE)
        );
        PlaceHolderLayout.setVerticalGroup(
            PlaceHolderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 358, Short.MAX_VALUE)
        );

        Score.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        Score.setText("Score : 0");

        Level.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        Level.setText("Level : 1");

        jButton1.setText("Main Menu");
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Score)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(Level)))
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addComponent(PlaceHolder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(150, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(Score)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Level)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(PlaceHolder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        gt.interrupt();
        this.setVisible(false);
        TetrisProject.viewStart();
    }//GEN-LAST:event_jButton1ActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Game().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Level;
    private javax.swing.JPanel PlaceHolder;
    private javax.swing.JLabel Score;
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
