package tetris.project;

import javax.swing.JOptionPane;

public class TetrisProject {

    private static Game g;
    private static Startup st;
    private static Leaderboard lb;
    
    public static void start(){
    g.setVisible(true);
    g.StartGame();
    }
    
    public static void viewLead(){
        lb.setVisible(true);
    }
    
    public static void viewStart(){
        st.setVisible(true);
    }
    
    public static void gameOver(int score){
        String name = JOptionPane.showInputDialog("Game Over!\nPlease enter your name.");
        g.setVisible(false);
        lb.addName(name, score);
    }
    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
             g = new Game();
            st = new Startup();
            lb = new Leaderboard();
        
            st.setVisible(true);   
            }
        });
    }
}
