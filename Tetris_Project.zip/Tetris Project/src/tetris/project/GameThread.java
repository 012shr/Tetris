package tetris.project;

import java.util.logging.Level;
import java.util.logging.Logger;

public class GameThread extends Thread{
    
    private Area a;
    private Game g;
    private int score;
    private int level = 1;
    private int increase = 3;
            
    
    private int pause = 500;
    private int speed = 100;
    public GameThread(Area a, Game g){
        this.a = a;
        this.g = g;
        
        g.scoreupdate(score);
        g.levelupdate(level);
    }
    
    @Override
    public void run(){
   
        while(true){
            a.spawn();
            
            while(a.fall()){
               try {
                Thread.sleep(pause);
               } catch (InterruptedException ex) {
                   return;
                }   
            }
            if(a.outofbounds()){
                TetrisProject.gameOver(score);
                break;
            }
            a.BlockToBack();
            score += a.clear();
            g.scoreupdate(score);
            int lvl = score / increase + 1;
            if(lvl > level){
                level = lvl;
                g.levelupdate(level);
                pause -= speed;
            }
        } 
    }
}
