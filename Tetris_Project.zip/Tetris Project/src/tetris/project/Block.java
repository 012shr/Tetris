package tetris.project;

import java.awt.Color;
import java.util.Random;

public class Block {
    private int[][] shape;
    private Color color;
    private int x,y;
    private int[][][] shapes;
    private int checkRotate;
    
    private Color[] listcolor = {Color.CYAN, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.RED, Color.WHITE, Color.PINK};
    
    public Block(int [][] shapes){
        this.shape = shapes;
        newshapes();
    }
    
    private void newshapes(){
        shapes = new int[4][][];
        for(int t = 0; t < 4; t++){
            int row = shape[0].length;
            int col = shape.length;
            
            shapes[t] = new int[row][col];
            for(int i = 0; i < row; i++){
                for(int f = 0; f < col; f++){
                    shapes[t][i][f] = shape[col - f - 1][i]; 
                }
            }
            shape = shapes[t];
        }
    }
    
    public void spawn(int Width){
        Random rand = new Random();
        checkRotate = rand.nextInt(shape.length);
        shape = shapes[checkRotate];
        y = -getHeight();
        x = rand.nextInt(Width - getWidth());
        
        color = listcolor[rand.nextInt(listcolor.length)];
    }
    
    public int[][] getShape(){
        return shape;
    }
    
    public Color getColor(){
        return color;
    }
    
    public int getHeight(){
        return shape.length;
    }
    
    public int getWidth(){
        return shape[0].length;
    }
    
    public int getX(){
        return x;
    }
    
    public void setX(int newX){
        x = newX;
    }
    
    public int getY(){
        return y;
    }
    
    public void setY(int newY){
        y = newY;
    }
    
    public void down(){
        y++;
    }
    
    public void left(){
        x--;
    }
    
    public void right(){
        x++;
    }
    
    public void rotate(){
        checkRotate++;
        if(checkRotate > 3){
            checkRotate = 0;
        }
        shape = shapes[checkRotate];
    }
    
    public int getBottom(){
        return y + getHeight();
    }
    
    public int getLeft(){
        return x;
    }
    
    public int getRight(){
        return x + getWidth();
    }
}
