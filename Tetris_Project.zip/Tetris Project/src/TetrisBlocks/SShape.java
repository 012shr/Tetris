package TetrisBlocks;

import tetris.project.Block;

public class SShape extends Block{
    public SShape(){
        super (new int[][] {{0, 1, 1}, {1, 1, 0}});
    }
}
