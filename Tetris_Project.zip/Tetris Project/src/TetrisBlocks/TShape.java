package TetrisBlocks;

import tetris.project.Block;


public class TShape extends Block{
    public TShape(){
        super (new int[][] {{1, 1, 1}, {0, 1, 0}});
    }
}
