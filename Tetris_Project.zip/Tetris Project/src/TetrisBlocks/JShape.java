package TetrisBlocks;

import tetris.project.Block;

public class JShape extends Block{
    public JShape(){
        super (new int[][] {{0, 1}, {0, 1}, {1, 1}});
    }
}
