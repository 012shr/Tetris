package TetrisBlocks;

import tetris.project.Block;

public class OShape extends Block{
    public OShape(){
        super (new int[][] {{1, 0}, {1, 1}});
    }
}
